# Earlier tool-session results (transcribed excerpts, not raw log files)

The original batches emitted output to the agent tool session; they were not
redirected to permanent files. The exact salient outcomes below preserve failure
history. Final reruns in this archive contain complete raw redirected logs.

1. Initial five statistics test files: `23 passed, 2 warnings in 5.43s`.
2. Initial browser startup in sandbox:
   `[Errno 1] error while attempting to bind on address ('127.0.0.1', 8787): [errno 1] operation not permitted`
   `Error: Process from config.webServer was not able to start. Exit code: 3`
3. Authorized localhost browser first attempt:
   `Error: locator.fill: Error: strict mode violation: getByLabel('agent_id') resolved to 2 elements`
   A group select and the agent text input both matched. Changed locator to exact
   textbox role. `1 failed` (the backfill stages had not run in this attempt).
4. After adding DLQ samples as an array in scalar labels, contract validation failed:
   `jsonschema.exceptions.ValidationError: [] is not of type 'string', 'number', 'boolean', 'null'`
   `1 failed, 22 passed, 2 warnings in 7.82s`.
   Changed samples to bounded scalar label pairs, preserving the published label shape.
5. New local heartbeat/login/file-size tests:
   `26 passed, 2 warnings in 8.73s`.
6. Shared Outbox regression initially:
   `FAILED tests/integration/runtime/test_outbox.py::test_enabled_kinds_only_safe_seed`
   `Extra items in the right set: 'console.stats.rollup'`
   `1 failed, 104 passed, 2 warnings in 20.08s`.
   Added implemented/fenced kind to the expected allowlist; combined rerun:
   `131 passed, 2 warnings in 25.05s`.
7. Real Scheduler tick replay test after that combined run:
   `1 passed, 2 warnings in 0.49s`.
8. Corrected real browser prior to moving its dedicated test directory:
   `1 passed (11.5s)`; default suite was then separated from the dedicated
   statistics backend configuration and both are chained in test:browser.
9. mypy after the initial sample change found reuse of `labels` with incompatible
   tuple/dict types; renamed the sample dictionary. Subsequent:
   `Success: no issues found in 426 source files`.
10. Public API checker first lacked the independent snapshot's TypeScript
    node_modules. A read-only symlink to existing SDK dependencies allowed it to
    run and report pre-existing W05 CLI provider/secret configuration drift.
    No whitelist was accepted by this task.

No production deployment, paid Provider, production benchmarks, or release action
was attempted. Raw final reruns are local development evidence only.
