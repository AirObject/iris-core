# Final archive run commands

Working directory: /private/tmp/imc-w07-work. No source changes after handoff.

- `UV_NO_SYNC=1 PYTHONPATH=/private/tmp/imc-w07-work/src:/private/tmp/imc-w07-work/sdk/python/src .venv/bin/python -m pytest tests/integration/runtime/test_outbox.py tests/integration/console/test_console_authentication.py tests/integration/console/test_console_worker_execution.py tests/integration/console/test_statistics_http.py tests/integration/console/test_statistics_operations.py tests/integration/console/test_statistics_projection.py tests/integration/migrations/test_statistics_migration.py tests/integration/recall/test_statistics_observations.py -q --no-cov` → pytest-final.log
- `CI=1 CONSOLE_BROWSER_EXECUTABLE='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome' ./node_modules/.bin/playwright test --config playwright.statistics.config.ts` from web/console → browser-final.log; local port permission authorized.
- `npm run check --prefix web/console` → console-check-final.log
- `UV_NO_SYNC=1 PYTHONPATH=/private/tmp/imc-w07-work/src:/private/tmp/imc-w07-work/sdk/python/src .venv/bin/mypy` → mypy-final.log
- `.venv/bin/ruff check src/iris_memory_core tests/integration/console/test_statistics* tests/integration/migrations/test_statistics_migration.py tests/integration/recall/test_statistics_observations.py` → ruff-final.log

Complete root integration make ci, Schema23→24 including W08, generated contract
version reconciliation and public snapshot review remain root-owned pending work.
